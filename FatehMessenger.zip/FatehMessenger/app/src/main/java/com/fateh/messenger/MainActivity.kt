package com.fateh.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF103D35)
private val Green = Color(0xFF176B57)
private val Pale = Color(0xFFF1F6F3)

 data class Person(val id: Int, val name: String, val code: String, val archived: Boolean = false, val messages: List<String> = emptyList())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FatehApp(onExit = { finish() }) }
    }
}

@Composable
private fun FatehApp(onExit: () -> Unit) {
    var people by remember { mutableStateOf(listOf(Person(1, "محادثة تجريبية", "FTH-0001", messages = listOf("أهلاً بك في الفاتح")))) }
    var selectedId by remember { mutableStateOf<Int?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var showArchived by remember { mutableStateOf(false) }
    var nextId by remember { mutableIntStateOf(2) }
    val selected = people.find { it.id == selectedId }

    BackHandler(enabled = selectedId != null || showArchived) {
        if (selectedId != null) selectedId = null else showArchived = false
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Pale)) {
        Surface(Modifier.fillMaxSize(), color = Pale) {
            Column {
                Row(
                    Modifier.fillMaxWidth().background(Forest).padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("الفاتح", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("FATEH MESSENGER · محمد الفاتح", color = Color(0xFFD5E8E1), fontSize = 11.sp)
                    }
                    Text("✦", color = Color(0xFFE2C477), fontSize = 30.sp)
                }
                when {
                    selected != null -> ChatScreen(
                        person = selected,
                        onBack = { selectedId = null },
                        onSend = { msg -> people = people.map { if (it.id == selected.id) it.copy(messages = it.messages + msg) else it } }
                    )
                    else -> {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { showAdd = true }, modifier = Modifier.weight(1f)) { Text("＋ إضافة شخص") }
                            OutlinedButton(onClick = { showArchived = !showArchived }, modifier = Modifier.weight(1f)) { Text(if (showArchived) "← الرئيسية" else "الأرشيف") }
                        }
                        Text(if (showArchived) "المحادثات المؤرشفة" else "محادثاتك", modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Forest)
                        val shown = people.filter { it.archived == showArchived }
                        if (shown.isEmpty()) {
                            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text(if (showArchived) "لا توجد محادثات مؤرشفة" else "أضف الأشخاص الذين تريد مراسلتهم فقط", textAlign = TextAlign.Center, color = Color.Gray)
                            }
                        } else {
                            LazyColumn(Modifier.weight(1f)) {
                                items(shown, key = { it.id }) { p ->
                                    Row(
                                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp)
                                            .background(Color.White, RoundedCornerShape(16.dp)).clickable { selectedId = p.id }.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(Modifier.size(44.dp).background(Green, CircleShape), contentAlignment = Alignment.Center) {
                                            Text(p.name.take(1), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                            Text(p.name, fontWeight = FontWeight.SemiBold, color = Forest)
                                            Text(p.messages.lastOrNull() ?: "لا توجد رسائل بعد", color = Color.Gray, fontSize = 13.sp, maxLines = 1)
                                            Text("رمز: ${p.code}", color = Green, fontSize = 11.sp)
                                        }
                                        TextButton(onClick = { people = people.map { if (it.id == p.id) it.copy(archived = !it.archived) else it } }) {
                                            Text(if (p.archived) "إلغاء الأرشفة" else "أرشفة", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("● وضع تجريبي محلي", color = Green, fontSize = 12.sp)
                            TextButton(onClick = onExit) { Text("خروج من التطبيق") }
                        }
                    }
                }
            }
        }
    }
    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var code by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("إضافة شخص يدوياً") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم الشخص") }, singleLine = true)
                    OutlinedTextField(value = code, onValueChange = { code = it.uppercase() }, label = { Text("رمز المستخدم (اختياري)") }, singleLine = true)
                    Text("الإضافة هنا محلية للتجربة؛ لا ترسل دعوة حقيقية إلى جهاز آخر.", fontSize = 12.sp, color = Color.Gray)
                }
            },
            confirmButton = { TextButton(onClick = {
                if (name.isNotBlank()) {
                    val safeCode = code.ifBlank { "FTH-${nextId.toString().padStart(4, '0')}" }
                    people = people + Person(nextId, name.trim(), safeCode)
                    nextId++
                    showAdd = false
                }
            }) { Text("إضافة") } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun ChatScreen(person: Person, onBack: () -> Unit, onSend: (String) -> Unit) {
    var draft by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Color.White).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← رجوع") }
            Column(Modifier.weight(1f)) {
                Text(person.name, fontWeight = FontWeight.Bold, color = Forest)
                Text("${person.code} · محادثة محلية تجريبية", fontSize = 11.sp, color = Color.Gray)
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(person.messages) { message ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Text(message, Modifier.background(Color(0xFFD8EEE3), RoundedCornerShape(14.dp)).padding(12.dp), color = Forest)
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color.White).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("اكتب رسالة...") }, singleLine = false)
            Spacer(Modifier.width(6.dp))
            Button(onClick = { if (draft.isNotBlank()) { onSend(draft.trim()); draft = "" } }) { Text("إرسال") }
        }
        Text("الرسائل الصوتية والتشفير والاتصال أونلاين/أوفلاين تحتاج إلى استكمال تقني قبل الاستخدام الحقيقي.", Modifier.fillMaxWidth().padding(8.dp), fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Center)
    }
}
